package uz.musiqa.player

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import kotlin.math.abs

object G {
    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    private val PAL = arrayOf(
        intArrayOf(0xFFB39DDB.toInt(), 0xFF26A69A.toInt()),
        intArrayOf(0xFFFFAB91.toInt(), 0xFFF48FB1.toInt()),
        intArrayOf(0xFF80DEEA.toInt(), 0xFFF8BBD0.toInt()),
        intArrayOf(0xFFFFCC80.toInt(), 0xFFFFAB91.toInt()),
        intArrayOf(0xFF81D4FA.toInt(), 0xFFA5D6A7.toInt()),
        intArrayOf(0xFFCE93D8.toInt(), 0xFF90CAF9.toInt())
    )

    fun pal(seed: String): IntArray = PAL[abs(seed.hashCode()) % PAL.size]

    fun grad(seed: String, r: Int, c: Context): GradientDrawable {
        val g = GradientDrawable(GradientDrawable.Orientation.TL_BR, pal(seed))
        g.cornerRadius = dp(c, r).toFloat()
        return g
    }

    fun glass(c: Context, r: Int, top: Int, bottom: Int): LayerDrawable {
        val o = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xEEFFFFFF.toInt(), 0x44FFFFFF, 0xBBFFFFFF.toInt()))
        o.cornerRadius = dp(c, r).toFloat()
        val i = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom))
        i.cornerRadius = dp(c, r).toFloat() - dp(c, 1)
        val ld = LayerDrawable(arrayOf(o, i))
        ld.setLayerInset(1, dp(c, 1), dp(c, 1), dp(c, 1), dp(c, 1))
        return ld
    }

    fun fmt(ms: Int): String {
        val s = ms / 1000
        return String.format("%d:%02d", s / 60, s % 60)
    }
}
