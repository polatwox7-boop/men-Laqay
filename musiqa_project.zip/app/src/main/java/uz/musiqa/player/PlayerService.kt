package uz.musiqa.player

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder

class PlayerService : Service() {
    private val l: () -> Unit = { update() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("musiqa", "Musiqa", NotificationManager.IMPORTANCE_LOW))
        Player.listeners.add(l)
        startFg()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "toggle" -> Player.toggle()
            "next" -> Player.next()
            "prev" -> Player.prev()
        }
        startFg()
        return START_STICKY
    }

    override fun onDestroy() {
        Player.listeners.remove(l)
        super.onDestroy()
    }

    private fun pi(a: String): PendingIntent =
        PendingIntent.getService(this, a.hashCode(), Intent(this, PlayerService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun notif(): Notification {
        val s = Player.cur
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val playIcon = if (Player.playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        return Notification.Builder(this, "musiqa")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(s?.title ?: "Musiqa")
            .setContentText(s?.artist ?: "")
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_media_previous), "Oldingi", pi("prev")).build())
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, playIcon), "Pauza", pi("toggle")).build())
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_media_next), "Keyingi", pi("next")).build())
            .setStyle(Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2))
            .build()
    }

    private fun startFg() {
        val n = notif()
        if (Build.VERSION.SDK_INT >= 34) startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK) else startForeground(7, n)
    }

    private fun update() {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(7, notif())
    }
}
