package uz.musiqa.player

import android.content.Context
import android.provider.MediaStore

object Library {
    private fun unk(s: String?, d: String) = if (s.isNullOrEmpty() || s == "<unknown>") d else s

    fun songs(ctx: Context): List<Song> {
        val out = ArrayList<Song>()
        val a = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.DATE_ADDED
        )
        try {
            ctx.contentResolver.query(
                a, proj,
                MediaStore.Audio.Media.IS_MUSIC + " != 0 AND " + MediaStore.Audio.Media.DURATION + " > 20000",
                null, MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    out.add(Song(c.getLong(0), c.getString(1) ?: "", unk(c.getString(2), "Noma’lum ijrochi"), unk(c.getString(3), "Noma’lum albom"), c.getLong(4), c.getLong(5)))
                }
            }
        } catch (e: Exception) {}
        return out
    }

    fun videos(ctx: Context): List<Video> {
        val out = ArrayList<Video>()
        val proj = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.TITLE, MediaStore.Video.Media.DURATION)
        try {
            ctx.contentResolver.query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, proj, null, null, MediaStore.Video.Media.DATE_ADDED + " DESC")?.use { c ->
                while (c.moveToNext()) out.add(Video(c.getLong(0), c.getString(1) ?: "Video", c.getLong(2)))
            }
        } catch (e: Exception) {}
        return out
    }
}
