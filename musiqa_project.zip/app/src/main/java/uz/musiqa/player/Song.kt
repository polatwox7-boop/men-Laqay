package uz.musiqa.player

data class Song(val id: Long, val title: String, val artist: String, val album: String, val duration: Long, val added: Long)
data class Video(val id: Long, val title: String, val duration: Long)
data class Item(val title: String, val sub: String, val seed: String, val kind: Int, val idx: Int)
