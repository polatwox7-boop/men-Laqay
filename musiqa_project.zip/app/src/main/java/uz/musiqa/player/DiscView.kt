package uz.musiqa.player

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.view.View
import kotlin.math.min

class DiscView(c: Context) : View(c) {
    var colors: IntArray = intArrayOf(0xFF80DEEA.toInt(), 0xFF26A69A.toInt())
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f
        p.style = Paint.Style.FILL
        p.shader = null
        p.color = 0xFF121212.toInt()
        c.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = r * 0.02f
        p.color = 0x33FFFFFF
        var k = 0.92f
        while (k > 0.55f) { c.drawCircle(cx, cy, r * k, p); k -= 0.07f }
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(cx - r * 0.5f, cy - r * 0.5f, cx + r * 0.5f, cy + r * 0.5f, colors[0], colors[1], Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r * 0.5f, p)
        p.shader = null
        p.color = Color.WHITE
        c.drawCircle(cx, cy, r * 0.1f, p)
        p.color = 0xFF121212.toInt()
        c.drawCircle(cx, cy, r * 0.045f, p)
    }
}
