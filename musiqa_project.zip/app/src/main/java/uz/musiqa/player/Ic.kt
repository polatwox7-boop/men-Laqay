package uz.musiqa.player

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class Ic(c: Context, t: Int = 0, col: Int = Color.WHITE) : View(c) {
    companion object {
        const val NOTE = 1; const val PLAY = 2; const val PAUSE = 3; const val NEXT = 4; const val PREV = 5
        const val SEARCH = 6; const val MIC = 7; const val STAR = 8; const val CLOCK = 9; const val DISC = 10
        const val HEAD = 11; const val VIDEO = 12; const val FILTER = 13; const val SORT = 14; const val LIST = 15
        const val HEART = 16; const val MORE = 17; const val SHUFFLE = 18
    }

    var type = t
        set(v) { field = v; invalidate() }
    var color = col
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f * 0.78f
        p.color = color
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.strokeWidth = r * 0.17f
        when (type) {
            NOTE -> {
                p.style = Paint.Style.FILL
                c.drawCircle(cx - r * 0.35f, cy + r * 0.55f, r * 0.34f, p)
                p.style = Paint.Style.STROKE
                p.strokeWidth = r * 0.2f
                c.drawLine(cx - r * 0.02f, cy + r * 0.5f, cx - r * 0.02f, cy - r * 0.85f, p)
                path.reset(); path.moveTo(cx - r * 0.02f, cy - r * 0.85f)
                path.quadTo(cx + r * 0.6f, cy - r * 0.6f, cx + r * 0.55f, cy - r * 0.05f)
                c.drawPath(path, p)
            }
            PLAY -> {
                p.style = Paint.Style.FILL
                path.reset(); path.moveTo(cx - r * 0.4f, cy - r * 0.7f); path.lineTo(cx + r * 0.75f, cy); path.lineTo(cx - r * 0.4f, cy + r * 0.7f); path.close()
                c.drawPath(path, p)
            }
            PAUSE -> {
                p.style = Paint.Style.FILL
                c.drawRoundRect(RectF(cx - r * 0.6f, cy - r * 0.7f, cx - r * 0.15f, cy + r * 0.7f), r * 0.15f, r * 0.15f, p)
                c.drawRoundRect(RectF(cx + r * 0.15f, cy - r * 0.7f, cx + r * 0.6f, cy + r * 0.7f), r * 0.15f, r * 0.15f, p)
            }
            NEXT, PREV -> {
                p.style = Paint.Style.FILL
                val d = if (type == NEXT) 1f else -1f
                path.reset(); path.moveTo(cx - d * r * 0.6f, cy - r * 0.6f); path.lineTo(cx + d * r * 0.4f, cy); path.lineTo(cx - d * r * 0.6f, cy + r * 0.6f); path.close()
                c.drawPath(path, p)
                c.drawRoundRect(RectF(cx + d * r * 0.5f - r * 0.1f, cy - r * 0.6f, cx + d * r * 0.5f + r * 0.1f, cy + r * 0.6f), r * 0.08f, r * 0.08f, p)
            }
            SEARCH -> {
                p.style = Paint.Style.STROKE
                c.drawCircle(cx - r * 0.1f, cy - r * 0.1f, r * 0.55f, p)
                c.drawLine(cx + r * 0.3f, cy + r * 0.3f, cx + r * 0.8f, cy + r * 0.8f, p)
            }
            MIC -> {
                p.style = Paint.Style.STROKE
                c.drawRoundRect(RectF(cx - r * 0.28f, cy - r * 0.8f, cx + r * 0.28f, cy + r * 0.2f), r * 0.28f, r * 0.28f, p)
                c.drawArc(RectF(cx - r * 0.55f, cy - r * 0.35f, cx + r * 0.55f, cy + r * 0.6f), 0f, 180f, false, p)
                c.drawLine(cx, cy + r * 0.6f, cx, cy + r * 0.9f, p)
            }
            STAR -> {
                p.style = Paint.Style.FILL
                path.reset()
                for (i in 0 until 10) {
                    val a = -Math.PI / 2 + i * Math.PI / 5
                    val rr = if (i % 2 == 0) r else r * 0.45f
                    val x = cx + (rr * cos(a)).toFloat()
                    val y = cy + (rr * sin(a)).toFloat()
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close(); c.drawPath(path, p)
            }
            CLOCK -> {
                p.style = Paint.Style.FILL
                c.drawCircle(cx, cy, r * 0.85f, p)
                p.color = 0xFFD9822B.toInt()
                p.style = Paint.Style.STROKE
                c.drawLine(cx, cy, cx, cy - r * 0.5f, p)
                c.drawLine(cx, cy, cx + r * 0.38f, cy + r * 0.2f, p)
            }
            DISC -> {
                p.style = Paint.Style.FILL
                c.drawCircle(cx, cy, r * 0.85f, p)
                p.color = 0xFF3E7C67.toInt()
                c.drawCircle(cx, cy, r * 0.5f, p)
                p.color = color
                c.drawCircle(cx, cy, r * 0.2f, p)
            }
            HEAD -> {
                p.style = Paint.Style.STROKE
                c.drawArc(RectF(cx - r * 0.8f, cy - r * 0.85f, cx + r * 0.8f, cy + r * 0.75f), 180f, 180f, false, p)
                p.style = Paint.Style.FILL
                c.drawRoundRect(RectF(cx - r * 0.9f, cy - r * 0.05f, cx - r * 0.45f, cy + r * 0.8f), r * 0.2f, r * 0.2f, p)
                c.drawRoundRect(RectF(cx + r * 0.45f, cy - r * 0.05f, cx + r * 0.9f, cy + r * 0.8f), r * 0.2f, r * 0.2f, p)
            }
            VIDEO -> {
                p.style = Paint.Style.STROKE
                c.drawRoundRect(RectF(cx - r * 0.85f, cy - r * 0.6f, cx + r * 0.85f, cy + r * 0.6f), r * 0.25f, r * 0.25f, p)
                p.style = Paint.Style.FILL
                path.reset(); path.moveTo(cx - r * 0.2f, cy - r * 0.3f); path.lineTo(cx + r * 0.35f, cy); path.lineTo(cx - r * 0.2f, cy + r * 0.3f); path.close()
                c.drawPath(path, p)
            }
            FILTER -> {
                p.style = Paint.Style.STROKE
                c.drawLine(cx - r * 0.8f, cy - r * 0.4f, cx + r * 0.8f, cy - r * 0.4f, p)
                c.drawLine(cx - r * 0.8f, cy + r * 0.4f, cx + r * 0.8f, cy + r * 0.4f, p)
                p.style = Paint.Style.FILL
                c.drawCircle(cx - r * 0.25f, cy - r * 0.4f, r * 0.24f, p)
                c.drawCircle(cx + r * 0.3f, cy + r * 0.4f, r * 0.24f, p)
            }
            SORT -> {
                p.style = Paint.Style.STROKE
                c.drawLine(cx - r * 0.35f, cy - r * 0.8f, cx - r * 0.35f, cy + r * 0.8f, p)
                c.drawLine(cx - r * 0.35f, cy + r * 0.8f, cx - r * 0.7f, cy + r * 0.45f, p)
                c.drawLine(cx - r * 0.35f, cy + r * 0.8f, cx - r * 0.0f, cy + r * 0.45f, p)
                c.drawLine(cx + r * 0.4f, cy + r * 0.8f, cx + r * 0.4f, cy - r * 0.8f, p)
                c.drawLine(cx + r * 0.4f, cy - r * 0.8f, cx + r * 0.05f, cy - r * 0.45f, p)
                c.drawLine(cx + r * 0.4f, cy - r * 0.8f, cx + r * 0.75f, cy - r * 0.45f, p)
            }
            LIST -> {
                p.style = Paint.Style.STROKE
                c.drawLine(cx - r * 0.8f, cy - r * 0.55f, cx + r * 0.8f, cy - r * 0.55f, p)
                c.drawLine(cx - r * 0.8f, cy, cx + r * 0.8f, cy, p)
                c.drawLine(cx - r * 0.8f, cy + r * 0.55f, cx + r * 0.3f, cy + r * 0.55f, p)
            }
            HEART -> {
                p.style = Paint.Style.FILL
                path.reset(); path.moveTo(cx, cy + r * 0.8f)
                path.cubicTo(cx - r * 1.3f, cy - r * 0.1f, cx - r * 0.6f, cy - r * 1.0f, cx, cy - r * 0.3f)
                path.cubicTo(cx + r * 0.6f, cy - r * 1.0f, cx + r * 1.3f, cy - r * 0.1f, cx, cy + r * 0.8f)
                path.close(); c.drawPath(path, p)
            }
            MORE -> {
                p.style = Paint.Style.FILL
                for (k in -1..1) c.drawCircle(cx, cy + k * r * 0.55f, r * 0.12f, p)
            }
            SHUFFLE -> {
                p.style = Paint.Style.STROKE
                c.drawLine(cx - r * 0.8f, cy - r * 0.5f, cx + r * 0.7f, cy + r * 0.5f, p)
                c.drawLine(cx - r * 0.8f, cy + r * 0.5f, cx + r * 0.7f, cy - r * 0.5f, p)
                c.drawLine(cx + r * 0.7f, cy + r * 0.5f, cx + r * 0.3f, cy + r * 0.45f, p)
                c.drawLine(cx + r * 0.7f, cy - r * 0.5f, cx + r * 0.3f, cy - r * 0.45f, p)
            }
        }
    }
}
