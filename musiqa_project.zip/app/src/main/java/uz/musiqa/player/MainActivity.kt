package uz.musiqa.player

import android.Manifest
import android.animation.ObjectAnimator
import android.app.Activity
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.ArrayAdapter
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.PopupMenu
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val ui = Handler(Looper.getMainLooper())
    private var all: List<Song> = emptyList()
    private var visible: List<Song> = emptyList()
    private var items: List<Item> = emptyList()
    private var vids: List<Video> = emptyList()
    private var mode = 0
    private var filter = ""
    private var artistF: String? = null
    private var albumF: String? = null
    private var query = ""
    private val favs = HashSet<Long>()
    private var animateRows = true
    private var expanded = false
    private var dragging = false
    private var videoPage = false

    private lateinit var list: ListView
    private lateinit var vlist: ListView
    private lateinit var chip: TextView
    private lateinit var empty: TextView
    private lateinit var tabViews: List<TextView>
    private lateinit var underline: View
    private lateinit var mini: FrameLayout
    private lateinit var miniDisc: DiscView
    private lateinit var miniTitle: TextView
    private lateinit var miniSub: TextView
    private lateinit var miniPlay: Ic
    private lateinit var miniAnim: ObjectAnimator
    private lateinit var panel: LinearLayout
    private lateinit var bigDisc: DiscView
    private lateinit var bigAnim: ObjectAnimator
    private lateinit var bigTitle: TextView
    private lateinit var bigSub: TextView
    private lateinit var seek: SeekBar
    private lateinit var tCur: TextView
    private lateinit var tEnd: TextView
    private lateinit var bigPlay: Ic
    private lateinit var shufIc: Ic
    private lateinit var scrim: View
    private lateinit var navIc1: Ic
    private lateinit var navIc2: Ic
    private lateinit var navTx1: TextView
    private lateinit var navTx2: TextView
    private lateinit var adapter: SongAdapter
    private val listener: () -> Unit = { ui.post { updatePlayer() } }

    private fun dp(v: Int) = G.dp(this, v)
    private fun prefs() = getSharedPreferences("musiqa", MODE_PRIVATE)

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val x = TextView(this)
        x.text = t
        x.textSize = size
        x.setTextColor(color)
        if (bold) x.setTypeface(x.typeface, Typeface.BOLD)
        x.includeFontPadding = false
        return x
    }

    private fun press(v: View) {
        v.setOnTouchListener { x, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> x.animate().scaleX(0.94f).scaleY(0.94f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> x.animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(OvershootInterpolator(2f)).start()
            }
            false
        }
    }

    private fun circle(size: Int, icon: Ic, top: Int, bottom: Int): FrameLayout {
        val f = FrameLayout(this)
        f.background = G.glass(this, size / 2, top, bottom)
        f.addView(icon, FrameLayout.LayoutParams(dp(size) / 2 + dp(6), dp(size) / 2 + dp(6), Gravity.CENTER))
        press(f)
        return f
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        Player.listeners.add(listener)
        ui.post(tick)
        val need = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            need.add(Manifest.permission.READ_MEDIA_AUDIO)
            need.add(Manifest.permission.READ_MEDIA_VIDEO)
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            need.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) load() else requestPermissions(missing.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        load()
    }

    override fun onDestroy() {
        Player.listeners.remove(listener)
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (expanded) collapse() else super.onBackPressed()
    }

    private fun load() {
        all = Library.songs(this)
        vids = Library.videos(this)
        favs.clear()
        prefs().getStringSet("fav", emptySet())?.forEach { s -> s.toLongOrNull()?.let { favs.add(it) } }
        vlist.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, vids.map { it.title })
        animateRows = true
        refresh()
    }

    private fun buildUi() {
        val root = FrameLayout(this)
        root.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFFF3EEFF.toInt(), 0xFFE7F6F2.toInt()))
        root.fitsSystemWindows = true

        list = ListView(this)
        list.divider = null
        list.dividerHeight = 0
        list.clipToPadding = false
        list.setPadding(0, 0, 0, dp(190))
        list.selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
        list.addHeaderView(header(), null, false)
        adapter = SongAdapter()
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ ->
            val i = pos - list.headerViewsCount
            if (i in items.indices) onItem(items[i])
        }
        root.addView(list, FrameLayout.LayoutParams(-1, -1))

        vlist = ListView(this)
        vlist.visibility = View.GONE
        vlist.clipToPadding = false
        vlist.setPadding(dp(8), dp(24), dp(8), dp(190))
        vlist.setOnItemClickListener { _, _, pos, _ ->
            val v = vids.getOrNull(pos) ?: return@setOnItemClickListener
            val u = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v.id)
            try { startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, "video/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) } catch (e: Exception) { Toast.makeText(this, "Video ochilmadi", Toast.LENGTH_SHORT).show() }
        }
        root.addView(vlist, FrameLayout.LayoutParams(-1, -1))

        scrim = View(this)
        scrim.setBackgroundColor(0x55000000)
        scrim.visibility = View.GONE
        scrim.setOnClickListener { collapse() }
        root.addView(scrim, FrameLayout.LayoutParams(-1, -1))

        root.addView(buildMini(), FrameLayout.LayoutParams(-1, dp(72), Gravity.BOTTOM).apply { setMargins(dp(14), 0, dp(14), dp(92)) })
        root.addView(buildPanel(), FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { setMargins(dp(12), 0, dp(12), dp(92)) })
        root.addView(buildNav(), FrameLayout.LayoutParams(-1, dp(68), Gravity.BOTTOM).apply { setMargins(dp(14), 0, dp(14), dp(14)) })
        setContentView(root)
    }

    private fun header(): View {
        val h = LinearLayout(this)
        h.orientation = LinearLayout.VERTICAL
        h.setPadding(dp(16), dp(14), dp(16), dp(4))

        val r1 = LinearLayout(this)
        r1.gravity = Gravity.CENTER_VERTICAL
        r1.addView(circle(46, Ic(this, Ic.FILTER, 0xFF1B1B1F.toInt()), 0xCCFFFFFF.toInt(), 0x88FFFFFF.toInt()), LinearLayout.LayoutParams(dp(46), dp(46)))
        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(14), 0, dp(14), 0)
        bar.background = G.glass(this, 24, 0xCCFFFFFF.toInt(), 0x88EDEAF5.toInt())
        bar.addView(Ic(this, Ic.SEARCH, 0xFF8A8A93.toInt()), LinearLayout.LayoutParams(dp(22), dp(22)))
        val et = EditText(this)
        et.hint = "Qo‘shiqlar, ijrochilarni qidirish"
        et.textSize = 14f
        et.maxLines = 1
        et.inputType = InputType.TYPE_CLASS_TEXT
        et.setBackgroundColor(Color.TRANSPARENT)
        et.setPadding(dp(8), 0, dp(8), 0)
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { query = s?.toString()?.trim()?.lowercase() ?: ""; animateRows = false; refresh() }
        })
        bar.addView(et, LinearLayout.LayoutParams(0, -1, 1f))
        bar.addView(Ic(this, Ic.MIC, 0xFF6B6B75.toInt()), LinearLayout.LayoutParams(dp(22), dp(22)))
        r1.addView(bar, LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(dp(10), 0, 0, 0) })
        h.addView(r1)

        val cards = LinearLayout(this)
        cards.setPadding(0, dp(16), 0, 0)
        fun card(label: String, c1: Int, c2: Int, icon: Int, act: () -> Unit): View {
            val l = LinearLayout(this)
            l.orientation = LinearLayout.VERTICAL
            l.setPadding(dp(14), dp(12), dp(10), dp(12))
            val g = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2))
            g.cornerRadius = dp(18).toFloat()
            val gloss = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x55FFFFFF, 0x00FFFFFF))
            gloss.cornerRadius = dp(18).toFloat()
            l.background = LayerDrawable(arrayOf(g, gloss))
            l.addView(Ic(this, icon, Color.WHITE), LinearLayout.LayoutParams(dp(28), dp(28)))
            val sp = View(this)
            l.addView(sp, LinearLayout.LayoutParams(1, 0, 1f))
            l.addView(tv(label, 14f, Color.WHITE, true))
            l.setOnClickListener { act() }
            press(l)
            return l
        }
        val cp = { LinearLayout.LayoutParams(0, dp(92), 1f).apply { setMargins(dp(4), 0, dp(4), 0) } }
        cards.addView(card("Saralanganlar", 0xFF8E5CF0.toInt(), 0xFF5B1FD0.toInt(), Ic.STAR) { filter = if (filter == "fav") "" else "fav"; clearSub(); animateRows = true; refresh() }, cp())
        cards.addView(card("Pleylistlar", 0xFF4F8F7F.toInt(), 0xFF2B6B58.toInt(), Ic.DISC) { Toast.makeText(this, "Pleylistlar keyingi versiyada", Toast.LENGTH_SHORT).show() }, cp())
        cards.addView(card("Eng so‘nggi", 0xFFF2A93B.toInt(), 0xFFC97708.toInt(), Ic.CLOCK) { filter = if (filter == "recent") "" else "recent"; clearSub(); animateRows = true; refresh() }, cp())
        h.addView(cards)

        val names = listOf("Qo‘shiqlar", "Videolar", "Ashulachilar", "Albomlar")
        val tabs = LinearLayout(this)
        val tvs = ArrayList<TextView>()
        for ((i, n) in names.withIndex()) {
            val t = tv(n, 16f, 0xFF8A8A93.toInt(), true)
            t.setPadding(dp(6), dp(18), dp(14), dp(10))
            t.setOnClickListener { selectTab(i) }
            tabs.addView(t)
            tvs.add(t)
        }
        tabViews = tvs
        val wrap = FrameLayout(this)
        wrap.addView(tabs)
        underline = View(this)
        val ug = GradientDrawable()
        ug.setColor(0xFF1B1B1F.toInt())
        ug.cornerRadius = dp(3).toFloat()
        underline.background = ug
        wrap.addView(underline, FrameLayout.LayoutParams(dp(30), dp(4), Gravity.BOTTOM or Gravity.START))
        h.addView(wrap)

        chip = tv("", 13f, 0xFF1B1B1F.toInt(), true)
        chip.setPadding(dp(14), dp(8), dp(14), dp(8))
        chip.background = G.glass(this, 16, 0xCCFFFFFF.toInt(), 0x88FFFFFF.toInt())
        chip.visibility = View.GONE
        chip.setOnClickListener { filter = ""; clearSub(); animateRows = true; refresh() }
        h.addView(chip, LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, dp(6), 0, dp(4)) })

        val sh = LinearLayout(this)
        sh.gravity = Gravity.CENTER_VERTICAL
        sh.setPadding(0, dp(12), 0, dp(4))
        val pc = FrameLayout(this)
        val pg = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFFA06BFF.toInt(), 0xFF6A2BE0.toInt()))
        pg.shape = GradientDrawable.OVAL
        pc.background = pg
        pc.addView(Ic(this, Ic.PLAY, Color.WHITE), FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
        sh.addView(pc, LinearLayout.LayoutParams(dp(38), dp(38)))
        val st = tv("Aralashtirish", 17f, 0xFF1B1B1F.toInt(), true)
        st.setPadding(dp(12), 0, 0, 0)
        sh.addView(st, LinearLayout.LayoutParams(0, -2, 1f))
        sh.addView(Ic(this, Ic.SORT, 0xFF1B1B1F.toInt()), LinearLayout.LayoutParams(dp(26), dp(26)).apply { setMargins(0, 0, dp(14), 0) })
        sh.addView(Ic(this, Ic.LIST, 0xFF1B1B1F.toInt()), LinearLayout.LayoutParams(dp(26), dp(26)))
        sh.setOnClickListener {
            if (visible.isNotEmpty()) { Player.shuffle = true; Player.play(this, visible, kotlin.random.Random.nextInt(visible.size)) }
        }
        press(sh)
        h.addView(sh)

        empty = tv("Qo‘shiqlar topilmadi. Telefon xotirasida musiqa fayllari bo‘lishi va ruxsat berilgan bo‘lishi kerak.", 13.5f, 0xFF6B6B75.toInt())
        empty.setPadding(0, dp(24), 0, dp(24))
        empty.visibility = View.GONE
        h.addView(empty)
        selectTabUi(0)
        return h
    }

    private fun clearSub() { artistF = null; albumF = null }

    private fun selectTabUi(i: Int) {
        for ((k, t) in tabViews.withIndex()) t.setTextColor(if (k == i) 0xFF1B1B1F.toInt() else 0xFF8A8A93.toInt())
        val t = tabViews[i]
        t.post {
            val lp = underline.layoutParams
            lp.width = (t.width - dp(14)).coerceAtLeast(dp(20))
            underline.layoutParams = lp
            underline.animate().translationX(t.left.toFloat() + dp(6)).setDuration(260).setInterpolator(OvershootInterpolator(1.3f)).start()
        }
    }

    private fun selectTab(i: Int) {
        selectTabUi(i)
        if (i == 1) { showVideos(true); return }
        showVideos(false)
        mode = when (i) { 2 -> 1; 3 -> 2; else -> 0 }
        clearSub()
        animateRows = true
        refresh()
    }

    private fun showVideos(v: Boolean) {
        videoPage = v
        list.visibility = if (v) View.GONE else View.VISIBLE
        vlist.visibility = if (v) View.VISIBLE else View.GONE
        val on = 0xFF1B1B1F.toInt()
        val off = 0xFF9A9AA3.toInt()
        navIc1.color = if (v) off else on
        navTx1.setTextColor(if (v) off else on)
        navIc2.color = if (v) on else off
        navTx2.setTextColor(if (v) on else off)
        if (v) selectTabUi(1)
    }

    private fun buildNav(): View {
        val n = LinearLayout(this)
        n.gravity = Gravity.CENTER
        n.background = G.glass(this, 34, 0xCCFFFFFF.toInt(), 0x99FFFFFF.toInt())
        n.elevation = dp(6).toFloat()
        fun item(label: String, type: Int, act: () -> Unit): Triple<View, Ic, TextView> {
            val l = LinearLayout(this)
            l.orientation = LinearLayout.VERTICAL
            l.gravity = Gravity.CENTER
            val ic = Ic(this, type, 0xFF9A9AA3.toInt())
            val t = tv(label, 11.5f, 0xFF9A9AA3.toInt(), true)
            t.setPadding(0, dp(3), 0, 0)
            l.addView(ic, LinearLayout.LayoutParams(dp(28), dp(28)))
            l.addView(t)
            l.setOnClickListener { act() }
            press(l)
            return Triple(l, ic, t)
        }
        val a = item("Mening musiqam", Ic.HEAD) { selectTab(0) }
        val b = item("Ko‘rish", Ic.VIDEO) { selectTab(1) }
        navIc1 = a.second; navTx1 = a.third; navIc2 = b.second; navTx2 = b.third
        n.addView(a.first, LinearLayout.LayoutParams(0, -1, 1f))
        n.addView(b.first, LinearLayout.LayoutParams(0, -1, 1f))
        navIc1.color = 0xFF1B1B1F.toInt()
        navTx1.setTextColor(0xFF1B1B1F.toInt())
        return n
    }

    private fun buildMini(): View {
        mini = FrameLayout(this)
        mini.visibility = View.GONE
        val pill = LinearLayout(this)
        pill.gravity = Gravity.CENTER_VERTICAL
        pill.setPadding(dp(52), 0, dp(12), 0)
        pill.background = G.glass(this, 32, 0xDD8ED6CE.toInt(), 0xDD4FA9A0.toInt())
        pill.elevation = dp(8).toFloat()
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        miniTitle = tv("", 15f, Color.WHITE, true)
        miniTitle.maxLines = 1
        miniTitle.ellipsize = TextUtils.TruncateAt.END
        miniSub = tv("", 12.5f, 0xCCFFFFFF.toInt())
        miniSub.maxLines = 1
        miniSub.ellipsize = TextUtils.TruncateAt.END
        col.addView(miniTitle)
        col.addView(miniSub)
        pill.addView(col, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(34), 0, dp(8), 0) })
        miniPlay = Ic(this, Ic.PLAY, Color.WHITE)
        val pb = circle(44, miniPlay, 0x66FFFFFF, 0x33FFFFFF)
        pb.setOnClickListener { Player.toggle() }
        pill.addView(pb, LinearLayout.LayoutParams(dp(44), dp(44)))
        val nx = circle(44, Ic(this, Ic.NEXT, Color.WHITE), 0x66FFFFFF, 0x33FFFFFF)
        nx.setOnClickListener { Player.next() }
        pill.addView(nx, LinearLayout.LayoutParams(dp(44), dp(44)).apply { setMargins(dp(8), 0, 0, 0) })
        pill.setOnClickListener { expand() }
        mini.addView(pill, FrameLayout.LayoutParams(-1, dp(64), Gravity.CENTER_VERTICAL))
        miniDisc = DiscView(this)
        miniDisc.elevation = dp(10).toFloat()
        mini.addView(miniDisc, FrameLayout.LayoutParams(dp(72), dp(72), Gravity.START or Gravity.CENTER_VERTICAL))
        miniAnim = ObjectAnimator.ofFloat(miniDisc, "rotation", 0f, 360f)
        miniAnim.duration = 7000
        miniAnim.repeatCount = ObjectAnimator.INFINITE
        miniAnim.interpolator = LinearInterpolator()
        return mini
    }

    private fun buildPanel(): View {
        panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.gravity = Gravity.CENTER_HORIZONTAL
        panel.setPadding(dp(22), dp(12), dp(22), dp(22))
        panel.background = G.glass(this, 38, 0xEE8ED6CE.toInt(), 0xEE3E968C.toInt())
        panel.elevation = dp(12).toFloat()
        panel.visibility = View.GONE
        val handle = View(this)
        val hg = GradientDrawable()
        hg.setColor(0x88FFFFFF.toInt())
        hg.cornerRadius = dp(3).toFloat()
        handle.background = hg
        panel.addView(handle, LinearLayout.LayoutParams(dp(44), dp(5)))
        bigDisc = DiscView(this)
        panel.addView(bigDisc, LinearLayout.LayoutParams(dp(170), dp(170)).apply { setMargins(0, dp(16), 0, dp(12)) })
        bigAnim = ObjectAnimator.ofFloat(bigDisc, "rotation", 0f, 360f)
        bigAnim.duration = 7000
        bigAnim.repeatCount = ObjectAnimator.INFINITE
        bigAnim.interpolator = LinearInterpolator()
        bigTitle = tv("", 19f, Color.WHITE, true)
        bigTitle.maxLines = 1
        bigTitle.ellipsize = TextUtils.TruncateAt.END
        bigTitle.gravity = Gravity.CENTER
        bigSub = tv("", 14f, 0xDDFFFFFF.toInt())
        bigSub.maxLines = 1
        panel.addView(bigTitle, LinearLayout.LayoutParams(-1, -2))
        panel.addView(bigSub, LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, dp(4), 0, dp(10)) })
        val sr = LinearLayout(this)
        sr.gravity = Gravity.CENTER_VERTICAL
        tCur = tv("0:00", 12f, Color.WHITE)
        tEnd = tv("0:00", 12f, Color.WHITE)
        seek = SeekBar(this)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) tCur.text = G.fmt(p) }
            override fun onStartTrackingTouch(s: SeekBar?) { dragging = true }
            override fun onStopTrackingTouch(s: SeekBar?) { dragging = false; Player.seek(seek.progress) }
        })
        sr.addView(tCur)
        sr.addView(seek, LinearLayout.LayoutParams(0, -2, 1f))
        sr.addView(tEnd)
        panel.addView(sr, LinearLayout.LayoutParams(-1, -2))
        val cr = LinearLayout(this)
        cr.gravity = Gravity.CENTER
        cr.setPadding(0, dp(12), 0, 0)
        shufIc = Ic(this, Ic.SHUFFLE, 0xAAFFFFFF.toInt())
        val sb = FrameLayout(this)
        sb.addView(shufIc, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
        sb.setOnClickListener { Player.setShuffle(!Player.shuffle) }
        press(sb)
        cr.addView(sb, LinearLayout.LayoutParams(dp(48), dp(48)))
        val pv = circle(48, Ic(this, Ic.PREV, Color.WHITE), 0x55FFFFFF, 0x33FFFFFF)
        pv.setOnClickListener { Player.prev() }
        cr.addView(pv, LinearLayout.LayoutParams(dp(54), dp(54)).apply { setMargins(dp(8), 0, dp(8), 0) })
        bigPlay = Ic(this, Ic.PLAY, 0xFF1F5E57.toInt())
        val bp = circle(64, bigPlay, 0xFFFFFFFF.toInt(), 0xDDE9FFFB.toInt())
        bp.setOnClickListener { Player.toggle() }
        cr.addView(bp, LinearLayout.LayoutParams(dp(68), dp(68)))
        val nx = circle(48, Ic(this, Ic.NEXT, Color.WHITE), 0x55FFFFFF, 0x33FFFFFF)
        nx.setOnClickListener { Player.next() }
        cr.addView(nx, LinearLayout.LayoutParams(dp(54), dp(54)).apply { setMargins(dp(8), 0, dp(8), 0) })
        val sp = View(this)
        cr.addView(sp, LinearLayout.LayoutParams(dp(48), dp(48)))
        panel.addView(cr, LinearLayout.LayoutParams(-1, -2))
        return panel
    }

    private fun expand() {
        if (expanded) return
        expanded = true
        scrim.visibility = View.VISIBLE
        scrim.alpha = 0f
        scrim.animate().alpha(1f).setDuration(250).start()
        panel.visibility = View.VISIBLE
        panel.pivotX = panel.width / 2f
        panel.pivotY = dp(400).toFloat()
        panel.alpha = 0f
        panel.scaleX = 0.7f
        panel.scaleY = 0.5f
        panel.translationY = dp(60).toFloat()
        panel.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f).setDuration(480).setInterpolator(OvershootInterpolator(1.1f)).start()
        mini.animate().alpha(0f).scaleX(0.92f).setDuration(200).start()
        updatePlayer()
    }

    private fun collapse() {
        if (!expanded) return
        expanded = false
        scrim.animate().alpha(0f).setDuration(220).withEndAction { scrim.visibility = View.GONE }.start()
        panel.animate().alpha(0f).scaleX(0.8f).scaleY(0.6f).translationY(dp(50).toFloat()).setDuration(260).withEndAction { panel.visibility = View.GONE }.start()
        mini.animate().alpha(1f).scaleX(1f).setDuration(300).start()
    }

    private fun updatePlayer() {
        val s = Player.cur
        if (s == null) { mini.visibility = View.GONE; return }
        if (mini.visibility != View.VISIBLE) {
            mini.visibility = View.VISIBLE
            mini.translationY = dp(170).toFloat()
            mini.alpha = 0f
            mini.animate().translationY(0f).alpha(1f).setDuration(520).setInterpolator(OvershootInterpolator(1.2f)).start()
        }
        miniTitle.text = s.title
        miniSub.text = s.artist
        bigTitle.text = s.title
        bigSub.text = s.artist
        val pal = G.pal(s.title)
        miniDisc.colors = pal
        bigDisc.colors = pal
        val t = if (Player.playing) Ic.PAUSE else Ic.PLAY
        miniPlay.type = t
        bigPlay.type = t
        if (Player.playing) {
            if (!miniAnim.isStarted) miniAnim.start() else miniAnim.resume()
            if (!bigAnim.isStarted) bigAnim.start() else bigAnim.resume()
        } else {
            if (miniAnim.isStarted) miniAnim.pause()
            if (bigAnim.isStarted) bigAnim.pause()
        }
        seek.max = Player.duration
        tEnd.text = G.fmt(Player.duration)
        shufIc.color = if (Player.shuffle) Color.WHITE else 0x77FFFFFF
        animateRows = false
        adapter.notifyDataSetChanged()
    }

    private val tick = object : Runnable {
        override fun run() {
            if (expanded && !dragging && Player.cur != null) {
                seek.progress = Player.position
                tCur.text = G.fmt(Player.position)
            }
            ui.postDelayed(this, 500)
        }
    }

    private fun refresh() {
        var base = when (filter) {
            "fav" -> all.filter { favs.contains(it.id) }
            "recent" -> all.sortedByDescending { it.added }.take(50)
            else -> all
        }
        val a = artistF
        val b = albumF
        if (a != null) base = base.filter { it.artist == a }
        if (b != null) base = base.filter { it.album == b }
        if (query.isNotEmpty()) base = base.filter { it.title.lowercase().contains(query) || it.artist.lowercase().contains(query) }
        visible = base
        items = when (mode) {
            1 -> base.groupBy { it.artist }.map { (k, v) -> Item(k, v.size.toString() + " qo‘shiq", k, 1, 0) }
            2 -> base.groupBy { it.album }.map { (k, v) -> Item(k, v.size.toString() + " qo‘shiq", k, 2, 0) }
            else -> base.mapIndexed { i, s -> Item(s.title, s.artist + " | " + s.album, s.title, 0, i) }
        }
        val label = when {
            a != null -> "Ijrochi: $a  x"
            b != null -> "Albom: $b  x"
            filter == "fav" -> "Saralanganlar  x"
            filter == "recent" -> "Eng so‘nggi  x"
            else -> ""
        }
        chip.text = label
        chip.visibility = if (label.isEmpty()) View.GONE else View.VISIBLE
        empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        adapter.notifyDataSetChanged()
    }

    private fun onItem(it: Item) {
        when (it.kind) {
            0 -> Player.play(this, visible, it.idx)
            1 -> { artistF = it.title; mode = 0; selectTabUi(0); animateRows = true; refresh() }
            2 -> { albumF = it.title; mode = 0; selectTabUi(0); animateRows = true; refresh() }
        }
    }

    private fun saveFavs() {
        prefs().edit().putStringSet("fav", favs.map { it.toString() }.toSet()).apply()
    }

    inner class SongAdapter : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(p: Int) = items[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
            val it = items[p]
            val row = LinearLayout(this@MainActivity)
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(16), dp(8), dp(8), dp(8))
            val art = FrameLayout(this@MainActivity)
            art.background = G.grad(it.seed, 14, this@MainActivity)
            art.addView(Ic(this@MainActivity, if (it.kind == 0) Ic.NOTE else Ic.DISC, Color.WHITE), FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER))
            row.addView(art, LinearLayout.LayoutParams(dp(58), dp(58)))
            val col = LinearLayout(this@MainActivity)
            col.orientation = LinearLayout.VERTICAL
            col.setPadding(dp(14), 0, dp(8), 0)
            val song = if (it.kind == 0) visible.getOrNull(it.idx) else null
            val playing = song != null && Player.cur?.id == song.id
            val t = tv(it.title, 16f, if (playing) 0xFF1E8E7E.toInt() else 0xFF1B1B1F.toInt(), playing)
            t.maxLines = 1
            t.ellipsize = TextUtils.TruncateAt.END
            val s = tv(it.sub, 13f, 0xFF7B7B85.toInt())
            s.maxLines = 1
            s.ellipsize = TextUtils.TruncateAt.END
            s.setPadding(0, dp(4), 0, 0)
            col.addView(t)
            col.addView(s)
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            if (song != null) {
                val m = FrameLayout(this@MainActivity)
                m.addView(Ic(this@MainActivity, if (favs.contains(song.id)) Ic.HEART else Ic.MORE, if (favs.contains(song.id)) 0xFFE0457B.toInt() else 0xFF8A8A93.toInt()), FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
                m.setOnClickListener { v ->
                    val pm = PopupMenu(this@MainActivity, v)
                    pm.menu.add(0, 1, 0, if (favs.contains(song.id)) "Saralanganlardan olib tashlash" else "Saralanganlarga qo‘shish")
                    pm.setOnMenuItemClickListener {
                        if (favs.contains(song.id)) favs.remove(song.id) else favs.add(song.id)
                        saveFavs()
                        animateRows = false
                        refresh()
                        true
                    }
                    pm.show()
                }
                row.addView(m, LinearLayout.LayoutParams(dp(44), dp(44)))
            }
            if (animateRows && p < 14) {
                row.alpha = 0f
                row.translationY = dp(26).toFloat()
                row.animate().alpha(1f).translationY(0f).setStartDelay(p * 30L).setDuration(320).start()
            }
            return row
        }
    }
}
