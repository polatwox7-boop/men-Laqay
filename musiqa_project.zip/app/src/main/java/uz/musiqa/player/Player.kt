package uz.musiqa.player

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.os.PowerManager
import android.provider.MediaStore
import kotlin.random.Random

object Player {
    var queue: List<Song> = emptyList()
    var index = -1
    var shuffle = false
    private var mp: MediaPlayer? = null
    private var app: Context? = null
    val listeners = ArrayList<() -> Unit>()

    val cur: Song? get() = queue.getOrNull(index)
    val playing: Boolean get() = try { mp?.isPlaying == true } catch (e: Exception) { false }
    val position: Int get() = try { mp?.currentPosition ?: 0 } catch (e: Exception) { 0 }
    val duration: Int get() = try { mp?.duration ?: 0 } catch (e: Exception) { 0 }

    private fun fire() { for (l in ArrayList(listeners)) l() }

    fun play(ctx: Context, list: List<Song>, i: Int) {
        app = ctx.applicationContext
        queue = list
        index = i
        start()
    }

    private fun start() {
        val s = cur ?: return
        val c = app ?: return
        try {
            mp?.release()
            val m = MediaPlayer()
            m.setWakeMode(c, PowerManager.PARTIAL_WAKE_LOCK)
            m.setDataSource(c, ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, s.id))
            m.setOnCompletionListener { next() }
            m.prepare()
            m.start()
            mp = m
        } catch (e: Exception) {
            mp = null
        }
        try { c.startForegroundService(Intent(c, PlayerService::class.java)) } catch (e: Exception) {}
        fire()
    }

    fun toggle() {
        val m = mp ?: return
        try { if (m.isPlaying) m.pause() else m.start() } catch (e: Exception) {}
        fire()
    }

    fun next() {
        if (queue.isEmpty()) return
        index = if (shuffle) Random.nextInt(queue.size) else (index + 1) % queue.size
        start()
    }

    fun prev() {
        if (queue.isEmpty()) return
        if (position > 3000) { try { mp?.seekTo(0) } catch (e: Exception) {}; fire(); return }
        index = if (index - 1 < 0) queue.size - 1 else index - 1
        start()
    }

    fun seek(ms: Int) {
        try { mp?.seekTo(ms) } catch (e: Exception) {}
    }

    fun setShuffle(v: Boolean) { shuffle = v; fire() }
}
